### Utilities summary:
_ "utilities" contains all the necessary to create a Postgres container, dive into psql, run dbt commands, and make all the CRUD operations.

1_ An easy way to create a Postgres container to run your tests:

    _ First in your favorite shell run "psql_bash_linux_mac.sh" for Linux or Mac, or use "bash psql_bash_win.sh" in Windows, after follow the steps to create or access your container.

2_ Easily runs CRUD operations or run dbt commands using the "creating_mock_data.ipynb" notebook. 